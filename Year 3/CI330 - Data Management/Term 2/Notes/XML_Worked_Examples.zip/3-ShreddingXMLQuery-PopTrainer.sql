--populating new trainer table
declare @doc varchar(1000), @hdoc int -- variable declarations
set @doc = '
<root>
	<tbl_Course courseCode="B401" courseDate="2012-02-13" trainerName="Glynn French" />
	<tbl_Course courseCode="B424" courseDate="2012-03-13" trainerName="Glynn French" />
	<tbl_Course courseCode="RC22" courseDate="2012-03-24" trainerName="Jill Parsnip" />
	<tbl_Course courseCode="RC27" courseDate="2012-05-24" trainerName="Jill Parsnip" />
</root>'
exec sp_xml_preparedocument @hdoc output, @doc
-- setting a handle to @doc for OPENXML
insert into tbl_Trainer (TrainerName)
	select distinct trainerName from openxml(@hdoc, N'/root/tbl_Course')
					with tbl_Course
