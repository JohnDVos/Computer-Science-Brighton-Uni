--creating the tables
create table tbl_Trainer (
trainerID		int not null primary key identity,
trainerName	varchar(30)not null);

-- Create the new course table
Create table tbl_NewCourse (
courseCode		char(4) not null,
courseDate		date not null,
trainerId		int,
constraint pk_crs primary key(courseCode, courseDate),
constraint fk_crs_trn Foreign key (trainerID) references tbl_Trainer (trainerID) );



--populating new course table
declare @doc varchar(1000), @hdoc int -- variable declarations
set @doc = '
<root>
	<tbl_Course courseCode="B401" courseDate="2012-02-13" trainerName="Glynn French" />
	<tbl_Course courseCode="B424" courseDate="2012-03-13" trainerName="Glynn French" />
	<tbl_Course courseCode="RC22" courseDate="2012-03-24" trainerName="Jill Parsnip" />
	<tbl_Course courseCode="RC27" courseDate="2012-05-24" trainerName="Jill Parsnip" />
</root>'
exec sp_xml_preparedocument @hdoc output, @doc
-- setting a handle to @doc for OPENXML�
insert into tbl_NewCourse (courseCode, courseDate)
	select courseCode, courseDate from openxml(@hdoc, N'/root/tbl_Course')
					with tbl_Course

