-- courses table 
Create table tbl_Course (
courseCode		char(4) not null,
courseDate		date not null,
trainerName		varchar(30),
Primary key(courseCode, courseDate));

insert into tbl_Course
values
('B401', '2012-02-13', 'Glynn French');
insert into tbl_Course
values
('RC22','2012-03-24', 'Jill Parsnip');
insert into tbl_Course
values
('B424', '2012-03-13', 'Glynn French');
insert into tbl_Course
values
('RC27','2012-05-24', 'Jill Parsnip');
