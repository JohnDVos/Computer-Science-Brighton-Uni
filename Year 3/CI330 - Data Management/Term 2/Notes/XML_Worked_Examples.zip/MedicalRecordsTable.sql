CREATE TABLE [MedicalRecords](
   [PatientID] [int] IDENTITY(1,1) NOT NULL,
   [PatientRecord] [xml] NOT NULL,
   [ModifiedDate] [datetime] NOT NULL DEFAULT (getdate()),
PRIMARY KEY CLUSTERED 
(   [PatientID] ASC
) ON [PRIMARY]
) ON [PRIMARY]
GO
CREATE PRIMARY XML INDEX idx_PatientRecord on [MedicalRecords] (PatientRecord)
GO
CREATE XML INDEX idx_PatientRecord_Path on [MedicalRecords] (PatientRecord) USING XML INDEX idx_PatientRecord FOR PATH


INSERT INTO MedicalRecords (PatientRecord, ModifiedDate)
VALUES('<PatientRecord>  <PatientDetails>
    	<Name>Robert</Name>
    <Gender>Male</Gender>
    <Age>5</Age>
    <InsuranceInfo><Company>Blue Cross BlueShield</Company>
      <ID>D8456798</ID>
   </InsuranceInfo>
  </PatientDetails>
  <HospitalDetails>
    <Name>KK Hospital</Name>
    <Department>Pediatrics</Department>
  </HospitalDetails>
  <AdmissionDetails>
<RegistrationNo>D4321</RegistrationNo>
    <DateAdmitted>2004-05-02</DateAdmitted>
    <DateDischarged>2004-05-08</DateDischarged>
  </AdmissionDetails>
  <ProblemDetails>
   <Symptoms>
      <Symptom>Abdominal pain</Symptom>
      <Symptom>Dehydration</Symptom>
   </Symptoms>
    <Diagnosis>Diarrhea</Diagnosis>
   <TreatmentInfo>
     <Therapy>Oral Rehydration Therapy</Therapy>
     <PrescriptionDetails>
       <Item>Pepto-Bismol</Item>
       <Item>Electrolyte Solutions</Item>
      </PrescriptionDetails>
   </TreatmentInfo>
  </ProblemDetails>
</PatientRecord>',2012-01-04)
