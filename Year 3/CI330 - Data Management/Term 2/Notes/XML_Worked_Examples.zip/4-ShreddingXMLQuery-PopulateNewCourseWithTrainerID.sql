declare @doc varchar(1000), @hdoc int -- variable declarations
set @doc = '
<root>
	<tbl_Course courseCode="B401" courseDate="2012-02-13" trainerName="Glynn French" />
	<tbl_Course courseCode="B424" courseDate="2012-03-13" trainerName="Glynn French" />
	<tbl_Course courseCode="RC22" courseDate="2012-03-24" trainerName="Jill Parsnip" />
	<tbl_Course courseCode="RC27" courseDate="2012-05-24" trainerName="Jill Parsnip" />
</root>'
exec sp_xml_preparedocument @hdoc output, @doc
-- setting a handle to @doc for OPENXML

/* This code includes the logic for setting the foreign keys except for the specific 
syntax to access the XML document and update the modified courses table. 
Insert the appropriate code and test the result. */


declare @code char(4), @date datetime, @name varchar(30)
declare crs_courses cursor
	for select courseCode, courseDate from tbl_NewCourse
open crs_courses
fetch next from crs_courses into @code, @date
while @@fetch_status = 0
begin
	-- retrieve trainer name from the XML document
	select @name=trainerName from openxml(@hdoc, N'/root/tbl_Course')
					with tbl_Course where courseCode=@code and courseDate=@date


	-- update the modified course table to set the trainer ID for the trainer name
	update tbl_NewCourse set trainerID = 
		(select trainerID from tbl_Trainer where trainerName=@name)
		where courseCode=@code and courseDate=@date
			
	fetch next from crs_courses into @code, @date
end
close crs_courses
deallocate crs_courses
 
